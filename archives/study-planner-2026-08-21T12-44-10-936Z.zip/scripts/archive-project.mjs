import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const projectRoot = path.resolve(__dirname, "..");
const archivesDir = path.join(projectRoot, "archives");

const packageJson = JSON.parse(
    fs.readFileSync(path.join(projectRoot, "package.json"), "utf8"),
);

const projectName = String(
    packageJson.name || path.basename(projectRoot),
).replace(/[^a-zA-Z0-9._-]/g, "-");

const timestamp = new Date()
    .toISOString()
    .replace(/[:.]/g, "-");

const archiveName = `${projectName}-${timestamp}.zip`;
const archivePath = path.join(archivesDir, archiveName);

const excludedDirectories = new Set([
    "node_modules",
    ".next",
    ".git",
    ".turbo",
    ".vercel",
    "archives",
    "coverage",
    "dist",
    "build",
    "out",
    "playwright-report",
    "test-results",
]);

const excludedExactFiles = new Set([
    ".env",
    ".env.local",
    ".env.development",
    ".env.production",
    ".env.test",
    ".npmrc",
    ".netrc",
    ".DS_Store",
    "Thumbs.db",
]);

const excludedExtensions = new Set([
    ".log",
    ".pem",
    ".key",
    ".p12",
    ".pfx",
    ".jks",
    ".keystore",
    ".tsbuildinfo",
]);

const safeEnvFiles = new Set([
    ".env.example",
    ".env.sample",
    ".env.template",
]);

function shouldInclude(sourcePath) {
    const relativePath = path.relative(projectRoot, sourcePath);

    if (!relativePath) {
        return true;
    }

    const parts = relativePath.split(path.sep);
    const fileName = path.basename(sourcePath);

    if (parts.some((part) => excludedDirectories.has(part))) {
        return false;
    }

    if (safeEnvFiles.has(fileName)) {
        return true;
    }

    if (fileName === ".env" || fileName.startsWith(".env.")) {
        return false;
    }

    if (excludedExactFiles.has(fileName)) {
        return false;
    }

    if (excludedExtensions.has(path.extname(fileName))) {
        return false;
    }

    return true;
}

fs.mkdirSync(archivesDir, { recursive: true });

const tempRoot = fs.mkdtempSync(
    path.join(os.tmpdir(), `${projectName}-archive-`),
);

const tempProjectDir = path.join(
    tempRoot,
    projectName,
);

try {
    console.log("Preparing safe project copy...");

    fs.cpSync(projectRoot, tempProjectDir, {
        recursive: true,
        filter: shouldInclude,
    });

    console.log("Creating ZIP archive...");

    const result = spawnSync(
        "tar.exe",
        [
            "-a",
            "-c",
            "-f",
            archivePath,
            "-C",
            tempProjectDir,
            ".",
        ],
        {
            stdio: "inherit",
            shell: false,
        },
    );

    if (result.error) {
        throw result.error;
    }

    if (result.status !== 0) {
        throw new Error(
            `tar.exe exited with code ${result.status}`,
        );
    }

    const stats = fs.statSync(archivePath);
    const sizeMb = stats.size / 1024 / 1024;

    console.log("");
    console.log("Project archive created successfully.");
    console.log(`File: ${archivePath}`);
    console.log(`Size: ${sizeMb.toFixed(2)} MB`);
} finally {
    fs.rmSync(tempRoot, {
        recursive: true,
        force: true,
    });
}
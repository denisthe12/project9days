import { z } from "zod";

export const planDaySchema = z.object({
  day: z.number().int().positive(),
  topic: z.string().trim().min(1),
});

export const planSchema = z.object({
  id: z.string().trim().min(1),
  topic: z.string().trim().min(1),
  durationValue: z.number().positive(),
  durationUnit: z.enum(["days", "weeks"]),
  durationDays: z.number().int().positive(),
  dailyStudyMinutes: z.number().int().positive(),
  days: z.array(planDaySchema),
  createdAt: z.string().datetime({ offset: true }),
  updatedAt: z.string().datetime({ offset: true }),
});

import { describe, expect, it } from "vitest";

import { planDaySchema, planSchema } from "./plan.schema";

const validPlan = {
  id: "plan-1",
  topic: "TypeScript",
  durationValue: 2,
  durationUnit: "weeks",
  durationDays: 14,
  dailyStudyMinutes: 45,
  days: [
    { day: 1, topic: "Базовые типы" },
    { day: 2, topic: "Объединения типов" },
  ],
  createdAt: "2026-08-21T10:00:00.000Z",
  updatedAt: "2026-08-21T10:00:00.000Z",
};

describe("planDaySchema", () => {
  it("accepts a valid plan day", () => {
    expect(
      planDaySchema.safeParse({ day: 1, topic: "Введение" }).success,
    ).toBe(true);
  });

  it.each([0, -1])("rejects day value %s", (day) => {
    expect(planDaySchema.safeParse({ day, topic: "Введение" }).success).toBe(
      false,
    );
  });

  it("rejects an empty topic", () => {
    expect(planDaySchema.safeParse({ day: 1, topic: "" }).success).toBe(false);
  });

  it("rejects a whitespace-only topic", () => {
    expect(
      planDaySchema.safeParse({ day: 1, topic: " \t " }).success,
    ).toBe(false);
  });
});

describe("planSchema", () => {
  it("accepts a valid plan", () => {
    expect(planSchema.safeParse(validPlan).success).toBe(true);
  });

  it("rejects an unknown duration unit", () => {
    expect(
      planSchema.safeParse({ ...validPlan, durationUnit: "months" }).success,
    ).toBe(false);
  });

  it.each(["topic", "id"] as const)(
    "rejects a whitespace-only %s value",
    (field) => {
      expect(
        planSchema.safeParse({ ...validPlan, [field]: " \t " }).success,
      ).toBe(false);
    },
  );

  it.each([
    ["durationValue", 0],
    ["durationValue", -1],
    ["durationDays", 0],
    ["durationDays", -1],
    ["dailyStudyMinutes", 0],
    ["dailyStudyMinutes", -1],
  ] as const)("rejects %s value %s", (field, value) => {
    expect(planSchema.safeParse({ ...validPlan, [field]: value }).success).toBe(
      false,
    );
  });

  it.each(["createdAt", "updatedAt"] as const)(
    "rejects an invalid %s value",
    (field) => {
      expect(
        planSchema.safeParse({ ...validPlan, [field]: "not-a-date" }).success,
      ).toBe(false);
    },
  );
});

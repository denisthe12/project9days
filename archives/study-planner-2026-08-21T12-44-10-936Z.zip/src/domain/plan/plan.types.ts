import { z } from "zod";

import { planDaySchema, planSchema } from "./plan.schema";

export type PlanDay = z.infer<typeof planDaySchema>;
export type Plan = z.infer<typeof planSchema>;
export type DurationUnit = Plan["durationUnit"];

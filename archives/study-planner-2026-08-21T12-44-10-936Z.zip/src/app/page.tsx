export default function Home() {
  return (
    <main className="grid min-h-screen place-items-center bg-background px-4 text-foreground antialiased">
      <section className="max-w-prose text-center">
        <p className="text-sm font-medium text-muted-foreground">
          Этап 1 · Техническая основа
        </p>
        <h1 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">
          Учебный планировщик
        </h1>
        <p className="mt-4 leading-7 text-muted-foreground">
          Приложение подготовлено к дальнейшей разработке.
        </p>
      </section>
    </main>
  );
}
